package com.example.click_counter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
